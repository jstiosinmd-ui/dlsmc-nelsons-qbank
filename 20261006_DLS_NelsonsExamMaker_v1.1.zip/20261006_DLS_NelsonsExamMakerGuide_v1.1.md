# DLSMC Pediatrics Exam Maker

---

[Open the exam maker](20261006_DLS_NelsonsExamMaker_v1.1.html). Extract the ZIP before opening the HTML in a compatible browser. This package contains the exam maker and this guide. It has no standalone question-bank page or link to one.

The self-contained examiner tool lets you choose the question count, sections or specific topics, difficulty, and exam details. It generates a question-paper PDF with a blank answer sheet and a matching answer-key PDF. The credit `/jstiosin 2026` appears in the HTML footer and on every generated PDF page.

## Generate PDFs

1. Set the exam title, number of questions, duration, date, and difficulty. Choose Easy, Average, Difficult, Mixed, or a custom percentage mix.
2. Select sections or specific topics. The count must allow at least one question for every selected group.
3. Choose whether the key should include rationales and references. Traditional single-best-answer questions are selected by default; the optional legacy Type K setting retains the 40% cap.
4. Tap **Generate exam**. Review five questions at a time with Previous and Next.
5. On mobile, tap **Prepare exam PDF** or **Prepare answer key PDF**, then tap the corresponding **Save or open** link. If the browser opens a PDF preview, use its Save or Share control. Desktop downloads start directly.

The question-paper PDF includes a blank answer sheet. The answer-key PDF contains the matching answer grid and, when selected, explanations and references. Changing settings clears the old draw and its PDF links. Download PDFs and the optional exam record before closing the tab.

## Examiner use

Keep the HTML file and answer key with examiners. Distribute the generated question-paper PDF to examinees. The HTML still embeds the full question pool and answers so it can generate exams offline; removing the standalone study page does not make those embedded data private.

Questions, logos, scripts, PDF libraries, and fonts are contained in the file. No account, server, or internet connection is required when the browser supports local HTML apps. A file previewer that cannot run JavaScript cannot operate the tool.

## Question coverage

The unchanged source pool contains 6,700 Nelson Textbook of Pediatrics, 21st-edition questions across 33 sections, including the corrected September 29, 2026 Respiratory System content. Section 34, Laboratory Medicine, is not included. Difficulty labels are editorial estimates. This interface revision does not perform a fresh clinical source review.

## Design

The saved De Los Santos Medical Center (DLSMC) palette supplies Deep Green `#164711`, Hospital Green `#409538`, Care Mint `#DCF6DF`, Paper `#F5F7F5`, and Green Wash `#EDF6EC`. Deep green is used for small text and buttons to preserve readable contrast. The logo was retrieved from the [official DLSMC website](https://www.delossantosmed.ph/) on October 6, 2026. The original artwork, including its Metro Pacific Health lockup, is retained. The layout frames the PNG's empty transparent padding without changing the image bytes. The HTML file embeds the original downloaded PNG, with no redrawing or recoloring. PDFs use A4 pages and embedded Calibri fonts. These saved palettes are operational design systems; the package does not claim that they are published official hospital brand manuals.

## Verification

The exam-generation scripts, embedded questions, PDF engine, logos, and fonts are byte-for-byte unchanged from the tested v1.0 exam maker. This revision removes the study-page navigation and updates the examiner-only packaging. Mobile layout, exam generation, PDF download, and footer-credit checks are recorded in the local build evidence. Chrome desktop and touch emulation are used; physical phones and Safari are not tested.

## Files

- [20261006_DLS_NelsonsExamMaker_v1.1.html](20261006_DLS_NelsonsExamMaker_v1.1.html): self-contained exam maker.
- [20261006_DLS_NelsonsExamMakerGuide_v1.1.md](20261006_DLS_NelsonsExamMakerGuide_v1.1.md): this guide.
